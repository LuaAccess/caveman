#!/usr/bin/env node
// caveman-config.js — shared configuration and safe file I/O
// Personal fork — network calls removed, history size cap added.

'use strict';

const fs   = require('fs');
const path = require('path');
const os   = require('os');

const VALID_MODES = [
  'off', 'lite', 'full', 'ultra',
  'wenyan-lite', 'wenyan', 'wenyan-full', 'wenyan-ultra',
  'commit', 'review', 'compress'
];

// Max bytes for flag file reads. Longest valid value is "wenyan-ultra" (12 bytes).
const MAX_FLAG_BYTES = 64;

// Hard cap on the history file to prevent unbounded growth.
// ~5MB covers thousands of sessions before truncation is needed.
const MAX_HISTORY_BYTES = 5 * 1024 * 1024;

// ── Config resolution ──────────────────────────────────────────────────────
function getConfigDir() {
  if (process.env.XDG_CONFIG_HOME) return path.join(process.env.XDG_CONFIG_HOME, 'caveman');
  if (process.platform === 'win32') {
    return path.join(
      process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming'),
      'caveman'
    );
  }
  return path.join(os.homedir(), '.config', 'caveman');
}

function getConfigPath() {
  return path.join(getConfigDir(), 'config.json');
}

function getDefaultMode() {
  // 1. Environment variable
  const envMode = process.env.CAVEMAN_DEFAULT_MODE;
  if (envMode && VALID_MODES.includes(envMode.toLowerCase())) {
    return envMode.toLowerCase();
  }
  // 2. Config file
  try {
    const config = JSON.parse(fs.readFileSync(getConfigPath(), 'utf8'));
    if (config.defaultMode && VALID_MODES.includes(config.defaultMode.toLowerCase())) {
      return config.defaultMode.toLowerCase();
    }
  } catch (_) {}
  // 3. Default
  return 'full';
}

// ── Symlink-safe flag write ────────────────────────────────────────────────
function safeWriteFlag(flagPath, content) {
  const debug = process.env.CAVEMAN_DEBUG === '1';
  try {
    const flagDir = path.dirname(flagPath);
    fs.mkdirSync(flagDir, { recursive: true });

    // If parent dir is a symlink, resolve and verify ownership.
    let realFlagDir;
    try {
      const lstat = fs.lstatSync(flagDir);
      if (lstat.isSymbolicLink()) {
        realFlagDir = fs.realpathSync(flagDir);
        const realStat = fs.statSync(realFlagDir);
        if (!realStat.isDirectory()) { if (debug) process.stderr.write('[caveman] safeWriteFlag: symlink target not a dir\n'); return; }
        if (typeof process.getuid === 'function') {
          if (realStat.uid !== process.getuid()) { if (debug) process.stderr.write('[caveman] safeWriteFlag: symlink target owned by different user\n'); return; }
        } else {
          const home = path.resolve(os.homedir()).toLowerCase();
          const real = path.resolve(realFlagDir).toLowerCase();
          if (!real.startsWith(home + path.sep) && real !== home) { if (debug) process.stderr.write('[caveman] safeWriteFlag: symlink outside home\n'); return; }
        }
      } else {
        realFlagDir = flagDir;
      }
    } catch (_) { return; }

    // Flag file itself must never be a symlink.
    const realFlagPath = path.join(realFlagDir, path.basename(flagPath));
    try { if (fs.lstatSync(realFlagPath).isSymbolicLink()) return; } catch (e) { if (e.code !== 'ENOENT') return; }

    // Atomic write: temp → rename, O_NOFOLLOW, 0600 perms.
    const tempPath = path.join(realFlagDir, `.caveman-tmp.${process.pid}.${Date.now()}`);
    const O_NOFOLLOW = typeof fs.constants.O_NOFOLLOW === 'number' ? fs.constants.O_NOFOLLOW : 0;
    const flags = fs.constants.O_WRONLY | fs.constants.O_CREAT | fs.constants.O_EXCL | O_NOFOLLOW;
    let fd;
    try {
      fd = fs.openSync(tempPath, flags, 0o600);
      fs.writeSync(fd, String(content));
      try { fs.fchmodSync(fd, 0o600); } catch (_) {}
    } finally { if (fd !== undefined) fs.closeSync(fd); }
    fs.renameSync(tempPath, realFlagPath);
  } catch (_) { /* silent fail */ }
}

// ── Symlink-safe flag read ─────────────────────────────────────────────────
function readFlag(flagPath) {
  try {
    let st;
    try { st = fs.lstatSync(flagPath); } catch (_) { return null; }
    if (st.isSymbolicLink() || !st.isFile()) return null;
    if (st.size > MAX_FLAG_BYTES) return null;

    const O_NOFOLLOW = typeof fs.constants.O_NOFOLLOW === 'number' ? fs.constants.O_NOFOLLOW : 0;
    let fd, out;
    try {
      fd = fs.openSync(flagPath, fs.constants.O_RDONLY | O_NOFOLLOW);
      const buf = Buffer.alloc(MAX_FLAG_BYTES);
      const n = fs.readSync(fd, buf, 0, MAX_FLAG_BYTES, 0);
      out = buf.slice(0, n).toString('utf8');
    } finally { if (fd !== undefined) fs.closeSync(fd); }

    const raw = out.trim().toLowerCase();
    return VALID_MODES.includes(raw) ? raw : null;
  } catch (_) { return null; }
}

// ── Symlink-safe append (for history log) ─────────────────────────────────
function appendFlag(filePath, line) {
  try {
    const dir = path.dirname(filePath);
    fs.mkdirSync(dir, { recursive: true });

    let realDir;
    try {
      const lstat = fs.lstatSync(dir);
      if (lstat.isSymbolicLink()) {
        realDir = fs.realpathSync(dir);
        const realStat = fs.statSync(realDir);
        if (!realStat.isDirectory()) return;
        if (typeof process.getuid === 'function') {
          if (realStat.uid !== process.getuid()) return;
        } else {
          const home = path.resolve(os.homedir()).toLowerCase();
          const real = path.resolve(realDir).toLowerCase();
          if (!real.startsWith(home + path.sep) && real !== home) return;
        }
      } else { realDir = dir; }
    } catch (_) { return; }

    const realPath = path.join(realDir, path.basename(filePath));
    try { if (fs.lstatSync(realPath).isSymbolicLink()) return; } catch (e) { if (e.code !== 'ENOENT') return; }

    // SECURITY FIX: check file size before appending to prevent unbounded growth.
    try {
      const st = fs.statSync(realPath);
      if (st.size > MAX_HISTORY_BYTES) return; // silently skip — rotate manually
    } catch (_) {}

    const O_NOFOLLOW = typeof fs.constants.O_NOFOLLOW === 'number' ? fs.constants.O_NOFOLLOW : 0;
    const openFlags = fs.constants.O_WRONLY | fs.constants.O_CREAT | fs.constants.O_APPEND | O_NOFOLLOW;
    let fd;
    try {
      fd = fs.openSync(realPath, openFlags, 0o600);
      fs.writeSync(fd, String(line).replace(/\n$/, '') + '\n');
      try { fs.fchmodSync(fd, 0o600); } catch (_) {}
    } finally { if (fd !== undefined) fs.closeSync(fd); }
  } catch (_) { /* silent fail */ }
}

// ── Symlink-safe history read (with size cap) ──────────────────────────────
function readHistory(filePath) {
  try {
    const st = fs.lstatSync(filePath);
    if (st.isSymbolicLink() || !st.isFile()) return [];

    // SECURITY FIX: enforce size cap on read too.
    if (st.size > MAX_HISTORY_BYTES) return [];

    const O_NOFOLLOW = typeof fs.constants.O_NOFOLLOW === 'number' ? fs.constants.O_NOFOLLOW : 0;
    let fd, raw;
    try {
      fd = fs.openSync(filePath, fs.constants.O_RDONLY | O_NOFOLLOW);
      raw = fs.readFileSync(fd, 'utf8');
    } finally { if (fd !== undefined) fs.closeSync(fd); }
    return raw.split('\n').filter(line => line.trim());
  } catch (_) { return []; }
}

module.exports = {
  getDefaultMode, getConfigDir, getConfigPath,
  VALID_MODES, safeWriteFlag, readFlag, appendFlag, readHistory
};
