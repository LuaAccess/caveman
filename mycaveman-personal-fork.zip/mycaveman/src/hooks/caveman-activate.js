#!/usr/bin/env node
// caveman-activate.js — SessionStart hook
// Runs once per Claude Code session start.
// Personal fork — no network calls, no telemetry.

'use strict';

const fs   = require('fs');
const path = require('path');
const os   = require('os');
const { getDefaultMode, safeWriteFlag } = require('./caveman-config');

const claudeDir   = process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
const flagPath    = path.join(claudeDir, '.caveman-active');
const settingsPath = path.join(claudeDir, 'settings.json');

const mode = getDefaultMode();

// "off" mode — clear flag and exit silently.
if (mode === 'off') {
  try { fs.unlinkSync(flagPath); } catch (_) {}
  process.stdout.write('OK');
  process.exit(0);
}

// Write the active mode flag (symlink-safe).
safeWriteFlag(flagPath, mode);

// Independent modes have their own skill files.
const INDEPENDENT_MODES = new Set(['commit', 'review', 'compress']);
if (INDEPENDENT_MODES.has(mode)) {
  process.stdout.write('CAVEMAN MODE ACTIVE — level: ' + mode + '. Behavior defined by /caveman-' + mode + ' skill.');
  process.exit(0);
}

const modeLabel = mode === 'wenyan' ? 'wenyan-full' : mode;

// Read SKILL.md from the plugin's skills directory.
let skillContent = '';
try {
  skillContent = fs.readFileSync(
    path.join(__dirname, '..', '..', 'skills', 'caveman', 'SKILL.md'), 'utf8'
  );
} catch (_) {}

let output;

if (skillContent) {
  const body = skillContent.replace(/^---[\s\S]*?---\s*/, '');

  // Filter intensity table and examples to only the active level.
  const filtered = body.split('\n').reduce((acc, line) => {
    const tableRowMatch = line.match(/^\|\s*\*\*(\S+?)\*\*\s*\|/);
    if (tableRowMatch) {
      if (tableRowMatch[1] === modeLabel) acc.push(line);
      return acc;
    }
    const exampleMatch = line.match(/^- (\S+?):\s/);
    if (exampleMatch) {
      if (exampleMatch[1] === modeLabel) acc.push(line);
      return acc;
    }
    acc.push(line);
    return acc;
  }, []);

  output = 'CAVEMAN MODE ACTIVE — level: ' + modeLabel + '\n\n' + filtered.join('\n');
} else {
  // Fallback ruleset when SKILL.md is not found.
  output =
    'CAVEMAN MODE ACTIVE — level: ' + modeLabel + '\n\n' +
    'Respond terse like smart caveman. All technical substance stay. Only fluff die.\n\n' +
    'ACTIVE EVERY RESPONSE. Off only: "stop caveman" / "normal mode".\n\n' +
    'Drop: articles, filler, pleasantries, hedging. Fragments OK. Technical terms exact.\n' +
    'Code blocks unchanged. Errors quoted exact.\n\n' +
    'Auto-clarity: drop caveman for security warnings, irreversible actions, ambiguous sequences. Resume after.';
}

// Statusline nudge if not yet configured (local check only — no network).
try {
  let hasStatusline = false;
  if (fs.existsSync(settingsPath)) {
    const settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
    if (settings.statusLine) hasStatusline = true;
  }
  if (!hasStatusline) {
    const isWindows = process.platform === 'win32';
    const scriptName = isWindows ? 'caveman-statusline.ps1' : 'caveman-statusline.sh';
    const scriptPath = path.join(__dirname, scriptName);
    const command = isWindows
      ? `powershell -ExecutionPolicy Bypass -File "${scriptPath}"`
      : `bash "${scriptPath}"`;
    output += '\n\nSTATUSLINE NOT SET UP: To show [CAVEMAN] badge, add to settings.json: ' +
      '"statusLine": { "type": "command", "command": ' + JSON.stringify(command) + ' }';
  }
} catch (_) {}

process.stdout.write(output);
